
import { executeQuery } from './db';

const handler = async (req, res) => {
  let data = await executeQuery('select * from test', []);
  res.json(data);
}

export default handler;

